<?php
/**
 * @package cat_up
 * @version 1.0.0
 */
/*
Plugin Name: Catfather
Plugin URI: localhost
Description: This is important plugin!
Authur: the CatFather
Version: 1.0.0
Authur URI: 127.1
*/


add_action('admin_notices', 'cat_up');

function cat_up(){
    printf("<p>Plugin Uploaded!</p>");
}


